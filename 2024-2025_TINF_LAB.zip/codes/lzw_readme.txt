Pozivanje funkcije encode_lzw:

- D - rječnik, lista simbola pri čemu indeks rječnika predstavlja indeks liste
- msg - poruka za kodiranje, string
- verbose - opcija za ispis algoritma korak po korak, boolean